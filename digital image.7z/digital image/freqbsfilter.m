function H=freqbsfilter(type,M,N,D0,W,n)
%带阻滤波器获取函数
%函数输入
%       type:字符串变量，指定滤波器的类型，'ideal','btw','gaussian'
%       M，N：频域滤波器的尺寸
%       D0：带阻滤波器的截至频率中心
%       w:带阻的带宽
%       n：巴特沃斯滤波器的阶数
%函数输出
%       H：M x N的矩阵表示，表示频域滤波器矩阵，数据类型为double
%函数描述
%       函数可以得到理想带带阻波器，巴特沃斯带阻滤波器，高斯带阻滤波器中的其中一种频域滤波器

u=-M/2:(M/2-1);
v=-N/2:(N/2-1);
[U,V]=meshgrid(u, v);
D=sqrt(U.^2+V.^2);%计算每个点到频谱中心的距离D

switch type
    case'ideal'
        H=double(or(D<(D0-W/2), D>D0+W/2));
    case'btw'
        if nargin==5
            n=1;
        end
        H=1./(1+(D*W./(D.^2-D0^2)).^(2*n));
    case'gaussian'
        H=1-exp(-0.5*((D.^2-D0^2)./(W*D)).^2);
    otherwise
        error('Unkonw filter type')
end
