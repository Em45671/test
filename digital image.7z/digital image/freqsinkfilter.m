function H=freqsinkfilter(type,M,N,u0,v0,D0,n)
%陷波阻止滤波器获取函数
%函数输入
%       type:字符串变量，指定滤波器的类型，'ideal','btw','gaussian'
%       M，N：频域滤波器的尺寸
%       u0,vo:频率阻止点
%       D0：频率阻止点的截至频率
%       n：巴特沃斯滤波器的阶数
%函数输出
%       H：M x N的矩阵表示，表示频域滤波器矩阵，数据类型为double
%函数描述
%       函数可以得到理想陷波滤波器，巴特沃斯陷波滤波器，高斯陷波滤波器中的其中一种频域滤波器
                                                                                                                        
u=-M/2:(M/2-1);
v=-N/2:(N/2-1);
[U,V]=meshgrid(u, v);

D1=sqrt((U-u0).^2+(V-v0).^2);
D2=sqrt((U+u0).^2+(V+v0).^2);

switch type
    case'ideal'
        mask1=D1<=D0;
        mask2=D2<=D0;
        mask=or(mask1,mask2);
        H=ones(M,N);
        H(mask)=0;
    case'btw'
        if nargin==6
            n=1;
        end
        H=1./(1+(D0^2./(D1.*D2)).^n);
    case'gaussian'
        H=1-exp(-0.5.*((D1.*D2)./D0*D0));
    otherwise
        error('Unkonw filter type')
end
