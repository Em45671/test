function H=freqhpfilter(type,M,N,D0,n)
%高通滤波器获取函数
%函数输入
%       type:字符串变量，指定滤波器的类型，'ideal','btw','gaussian'
%       M，N：频域滤波器的尺寸
%       D0：高通滤波器的截至频率
%       n：巴特沃斯滤波器的阶数
%函数输出
%       H：M x N的矩阵表示，表示频域滤波器矩阵，数据类型为double
%函数描述
%       函数可以得到理想高通滤波器，巴特沃斯高通滤波器，高斯高通滤波器中的其中一种频域滤波器


u=-M/2:(M/2-1);
v=-N/2:(N/2-1);
[U,V]=meshgrid(u, v);
D=sqrt(U.^2+V.^2);%计算每个点到频谱中心的距离D



switch type
    case'ideal'
        H=double(D>=D0);
    case'btw'
        if nargin==4
            n=1;
        end
        H=1./(1+(D0./D).^(2*n));
    case'gaussian'
        H=1-exp(-(D.^2)./(2*(D0^2)));
    otherwise
        error('Unkonw filter type')
end




