function H=freqlpfilter(type,M,N,D0,n)
%函数输入
%       type:字符串变量，指定滤波器的类型，'ideal','btw','gaussian'
%       M，N：频域滤波器的尺寸
%       D0：低通滤波器的截至频率
%       n：巴特沃斯滤波器的阶数
%函数输出
%       H：M x N的矩阵表示，表示频域滤波器矩阵，数据类型为double
%函数描述
%       函数可以得到理想低通滤波器，巴特沃斯低通滤波器，高斯低通滤波器中的其中一种频域滤波器

u=-M/2:(M/2-1);
v=-N/2:(N/2-1);
[U,V]=meshgrid(u, v);
D=sqrt(U.^2+V.^2);%计算每个点到频谱中心的距离D                                                                                                                                                                                              

switch type
    case'ideal'
        H=double(D<=D0);%理想低通滤波器，距离小于D0时通过
    case'btw'
        if nargin==4    %如果输入参数为4个，巴特沃斯滤波器的阶数为1
            n=1;
        end
        H=1./(1+(D./D0).^(2*n));%输入参数不为4个，则代表要使用巴特沃斯滤波器
    case'gaussian'
        H=exp(-(D.^2)./(2*(D0^2)));
    otherwise
        error('Unkonw filter type')
end







